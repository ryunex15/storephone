<!-- footer.php -->
<?php
// footer.php logic here
?>