<!-- header.php -->
<?php
// header.php logic here
?>