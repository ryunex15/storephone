<!-- simpan.php -->
<?php
// simpan.php logic here
?>