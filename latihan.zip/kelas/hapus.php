<!-- hapus.php -->
<?php
// hapus.php logic here
?>