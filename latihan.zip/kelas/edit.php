<!-- edit.php -->
<?php
// edit.php logic here
?>