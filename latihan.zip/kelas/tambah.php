<!-- tambah.php -->
<?php
// tambah.php logic here
?>