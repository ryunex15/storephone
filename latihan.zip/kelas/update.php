<!-- update.php -->
<?php
// update.php logic here
?>