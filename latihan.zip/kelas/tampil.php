<!-- tampil.php -->
<?php
// tampil.php logic here
?>