<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}
echo "Selamat datang, " . $_SESSION['user']['nama_petugas'];
?>