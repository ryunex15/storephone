<!-- cetak.php -->
<?php
// cetak.php logic here
?>